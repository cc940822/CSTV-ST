%% load data 
clc;clear;
load EC_case.mat

%% TVCS interpolation 
% EC measurements
Y = log(EC400_data(:,4));
% construct sampling matrix 
A = sampling_matrix(Dim,EC400_data(:,1));
% construct transformation matrix
DCT_subspace = [10,10];
Phi = phi_square(Dim,DCT_subspace);
% construct sensing matrix
A_Phi = A * Phi;
% setting hyperparameters
lambda =1e-4;
lambda_tv = 1e-3;
% solve the optimization problem 
[X] = admm_solver(Y,A_Phi,Phi,lambda,lambda_tv,Dim);
% reconstruct the columnized spatial field
result = Phi * X;
% reshape the spatial field
map = reshape(result,Dim);
%% evaluation metrics 
map_CSTV = map .*mask;
pred_CSTV= result(ECrand_data(:,1));
rmse_CSTV = rmse(ECrand_data(:,4),exp(pred_CSTV));

%% map show

F = figure('Units', 'centimeters','Position', [3 3 9 9]);
imagesc(map_CSTV)




