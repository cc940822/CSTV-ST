% This script presents the transformation process of spatial samples 
%  from spatial coordinates to the CS framework
%% data load

clc;clear
% load the shp file of EC-G400
Grid_400 = struct2table(shaperead('EC400.shp'));
% load the shp file of EC-Rand
Random_p = struct2table(shaperead('EC_rand.shp'));
%% data transformation

% substract the effecient data 
EC400 = [Grid_400.x, Grid_400.y, Grid_400.EC_mscm_];
ECrand = [Random_p.x, Random_p.y, Random_p.EC_mscm_];
% load the shp file of the area of interesting (AOI)
Edge = shaperead('range.shp');
% set the edge parameters of AOI
xlimits = [floor(Edge.BoundingBox(1,1)),ceil(Edge.BoundingBox(2,1))];
ylimits = [floor(Edge.BoundingBox(1,2)),ceil(Edge.BoundingBox(2,2))];
% set the spatial resolution
rasterSize = [25 25];
% Reference raster cells to map coordinates using MATLAB built-in functions
% ColumnsStartFrom-north , RowsStartFrom-west are two fixed parameters
R = maprefcells(xlimits,ylimits,rasterSize(1),rasterSize(2),'ColumnsStartFrom','north','RowsStartFrom','west');
% substract the size of map [nr, nc]
Dim = R.RasterSize;
% Find Indices of Cell from World Coordinates
[row_400,col_400] = worldToDiscrete(R,EC400(:,1),EC400(:,2));
CS_idx_400 = sub2ind(Dim,row_400,col_400);
[row_rand,col_rand] =  worldToDiscrete(R,ECrand(:,1),ECrand(:,2));
CS_idx_rand = sub2ind(Dim,row_rand,col_rand);
% integrate EC data and CS index
EC400 = [CS_idx_400,EC400,row_400, col_400];
ECrand = [CS_idx_rand,ECrand,row_rand, col_rand];
% sort the samples following the CS index
EC400_data = sortrows(EC400,1);
ECrand_data = sortrows(ECrand,1);

%% mask

% transform the AOI from shp to cells
Dim = R.RasterSize;
X_line = Edge.X(1:6);
Y_line = Edge.Y(1:6);
Grid_shp = [X_line',Y_line'];
[x_shp,y_shp] = worldToIntrinsic(R,X_line,Y_line);
% generate grid
x = 1:1:Dim(2);
y = 1:1:Dim(1);
[Est_X,Est_Y] = meshgrid(x,y);
Pos_est = [Est_X(:) Est_Y(:)];
% generate grid
[mask,on]=inpolygon(Est_X,Est_Y,x_shp,y_shp);
mask = double(mask) ;
mask(find(mask==0))=NaN;
NAN = nan(Dim) ;
%  map EC-G400 and AOI
imagesc(mask)
hold on 
scatter(col_400,row_400)
axis equal
