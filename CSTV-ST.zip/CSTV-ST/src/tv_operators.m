function [D_h,D_v] = tv_operators(Dim)
%   This function generates matrices of difference operators for total variation (TV)
%   Input:
%   Dim - Image size [nr, nc]
%   Output:
%   D_h - horizontal difference matrix
%   D_v - vertical Difference Matrix  
    
    nr = Dim(1); % number of row
    nc = Dim(2);  % number of column 
    dh = diag(-ones(nc,1,'gpuArray')) + diag(ones(nc-1,1,'gpuArray'), 1);
    dh(end,:) = 0;
    D_h = kron(dh, eye(nr));  
    dv = diag(-ones(nr,1,'gpuArray')) + diag(ones(nr-1,1,'gpuArray'), 1);
    dv(end,:) = 0;
    D_v = kron(eye(nc), dv);
end

