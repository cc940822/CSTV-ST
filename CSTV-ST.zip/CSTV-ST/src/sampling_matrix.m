function [A] = sampling_matrix(Dim,idx)
%  This function generates the sampling martix corresponding to
%  measurements
%  Input:  
%  Dim - size of the whole map  [nr,nc]  
%  idx - index of measurements in the columnized map
%  Output:  
%  A - sampling matrix
    A = eye(prod(Dim));
    A = A(idx,:);
end

