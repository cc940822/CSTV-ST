function [X] = admm_solver(Y,A,Phi,lambda,lambda_tv,im_size)
%  This function is the model solver of CSTV derived from the ADMM algorithm.
%  Input：
%  A - sensing matrix [M×K]
%  Y - measurements [M×1]
%  lambda - regularization parameter 
%  lambda_tv- regularization parameter 
%  Phi - sparse matrix used for searching coefficients [M×N]
%  im_size -  [nr, nc]

%  Outnput：
%  X - sparse coefficients 
%% Move data to GPU
A = gpuArray(A);
Y = gpuArray(Y);
Phi = gpuArray(Phi);
W = diag(ones(size(A,2),1,'gpuArray')) ;
%% Global constants and initialization
tStart = tic;
N = size(Y, 1);
X0 = 0;
[H_v,H_h] = Tv_matrix_GPU(im_size);
    
%% Precompute inverses on GPU
IF = inv(A' * A + W' * W + Phi' * Phi);
DF = inv(H_v' * H_v + H_h' * H_h + eye(prod(im_size), 'gpuArray'));
% Initialize solution
if X0 == 0
    X = IF * A' * Y;
end

%% Initialize variables on GPU
V = cell(4, 1);
D = cell(4, 1);

V{1} = A * X;
V{2} = W * X;
V{3} = Phi * X;
V{4} = cell(1, 2);
V{4}{1} = H_v * V{3};
V{4}{2} = H_h * V{3};  

D{1} = zeros(size(A, 1), 1, 'gpuArray');    
D{2} = zeros(size(X), 'gpuArray');    
D{3} = zeros(size(Phi, 1), 1, 'gpuArray');
D{4} = cell(1, 2);
D{4}{1} = zeros(size(Phi, 1), 1, 'gpuArray');
D{4}{2} = zeros(size(Phi, 1), 1, 'gpuArray');

%% ADMM parameters
tol1 = 1e-5;
tol2 = 1e-6;
miu = 0.0001;
i = 1;
res = inf;
res_rel = inf;
AL_iters = 3000;
Im_old = zeros(size(Phi, 1), 1, 'gpuArray');
    
    %% Main ADMM loop
while (i <= AL_iters) && (sum(abs(res)) > tol1) && (sum(abs(res_rel))> tol2)  
    % x-update
    Xi = A' * (V{1} + D{1}) + W' * (V{2} + D{2}) + Phi' * (V{3} + D{3});
    X = IF * Xi;
    Im_new = Phi * X;

    % Store previous V values
    V_hold = cell(4, 1);
    V_hold{1} = V{1};
    V_hold{2} = V{2};
    V_hold{3} = V{3};
    V_hold{4} = cell(1, 2);
    V_hold{4}{1} = V{4}{1};
    V_hold{4}{2} = V{4}{2};
   
    % V-update
    V{1} = (Y + miu * (A * X - D{1})) / (1 + miu);
    V{2} = SoftThresh_gpu(W * X - D{2}, lambda / miu);
    V{3} = DF * (H_v * (V{4}{1} + D{4}{1}) + H_h * (V{4}{2} + D{4}{2}) + Phi * X - D{3});
    V{4}{1} = SoftThresh_gpu(H_v * V{3} - D{4}{1}, lambda_tv / miu);   % vertical
    V{4}{2} = SoftThresh_gpu(H_h * V{3} - D{4}{2}, lambda_tv / miu);   % horizontal
    
    % D-update
    D{4}{1} = D{4}{1} - (H_v * V{3} - V{4}{1});
    D{4}{2} = D{4}{2} - (H_h * V{3} - V{4}{2});
    D{1} = D{1} - (A * X - V{1});
    D{2} = D{2} - (W * X - V{2});
    D{3} = D{3} - (Phi * X - V{3});
    
    % Compute residuals
    res(1) = norm(A * X - V{1}, 'fro');
    res(2) = norm(W * X - V{2}, 'fro');
    res(3) = norm(Phi * X - V{3}, 'fro');
    r_norm = sum(res);
    
    res_d(1) = norm(-miu * A' * (V{1} - V_hold{1}), 'fro');
    res_d(2) = norm(-miu * W' * (V{2} - V_hold{2}), 'fro');
    res_d(3) = norm(-miu * Phi' * (V{3} - V_hold{3}), 'fro');
    s_norm = sum(res_d);
    
    % Adaptive penalty parameter adjustment
    tau_incr = 1.05;
    if r_norm > 5 * s_norm
        miu = tau_incr * miu;
        D{4}{1} = D{4}{1} / tau_incr;
        D{4}{2} = D{4}{2} / tau_incr;
        D{1} = D{1} / tau_incr;
        D{2} = D{2} / tau_incr;
        D{3} = D{3} / tau_incr;
    elseif s_norm > 5 * r_norm
        miu = miu / tau_incr;
        D{4}{1} = D{4}{1} * tau_incr;
        D{4}{2} = D{4}{2} * tau_incr;
        D{1} = D{1} * tau_incr;
        D{2} = D{2} * tau_incr;
        D{3} = D{3} * tau_incr;
    end
    
    % Display progress
    if mod(i, 100) == 1
        res_rel = norm(Im_new - Im_old, 'fro') / norm(Im_new, 'fro');
        fprintf('iter = %i - miu = %2.6f, r_norm = %2.6f, s_norm = %2.6f, res_rel = %2.6f\n', ...
                i, miu, r_norm, s_norm, res_rel);
    end    
    Im_old = Im_new;
    i = i + 1;
end
tEnd = toc(tStart);
fprintf('Total time: %f seconds\n', tEnd);    
    
X = gather(X);
end


function r = SoftThresh_gpu(x,t)

s = abs(x) - t;
s = (s + abs(s))/2;
r = sign(x).*s;%
end
