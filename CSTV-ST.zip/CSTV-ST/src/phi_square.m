function [Phi] = phi_square(Dim_map,Dim_search_space)
%  This function generates the sparse matrix Phi corresponding to the regular DCT subspace.
%  Input:  
%  Dim_map - size of the whole map [nr,nc]
%  Dim_search_space - size of the searching space [h,v]
%  Output:  
%  Phi - sparse matrix

    W1 = dctmtx(Dim_map(1)); 
    W2 = dctmtx(Dim_map(2));
    C1 = W1';
    Phi = [];
    for i = 1:Dim_search_space(1)
        for j = 1:Dim_search_space(2)
    %         k = sub2ind([M N],i,j);
            col = C1(:,i)*W2(j,:);
            Phi = [Phi col(:)];
        end
    end
end

